const AWS = require('aws-sdk')

const dynamodb = new AWS.DynamoDB({
    apiVersion: '2012-08-10',
    region: 'us-east-2'
})
const uuid = require('uuid/v4')

exports.handler = async event => {
    const params = {
        Item: {
            ReviewId: {
                S: uuid()
            },
            Review: {
                S: 'No One You Know'
            },
            Title: {
                S: 'Call Me Today'
            },
            Rating: {
                N: '5'
            },
            User: {
                S: 'Zlatan'
            },
            Approved: {
                BOOL: true
            }
        },
        TableName: 'cleaning-reviews'
    }
    const dbresult = await dynamodb
        .putItem(params)
        .promise()
        .catch(err => {
            console.log(err, err.stack)
        })
    console.log(dbresult)
}
